# Affiliate App

## Backend
- Run with:
  ```bash
  cd backend
  npm install
  npm start
  ```

## Frontend
- Run with:
  ```bash
  cd frontend
  npm install
  npm start
  ```

Backend runs on port 4000. Frontend expects REACT_APP_API to point to backend (http://localhost:4000/api).