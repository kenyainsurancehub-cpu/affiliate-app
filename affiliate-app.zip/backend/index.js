const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();

const app = express();
app.use(cors());
app.use(express.json());

const db = new sqlite3.Database('./data.db');

// Init tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS affiliates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT, email TEXT, status TEXT DEFAULT 'pending', earnings INTEGER DEFAULT 0
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    affiliateId INTEGER, customerName TEXT, product TEXT, status TEXT DEFAULT 'new'
  )`);
});

// Routes
app.post('/api/affiliates', (req, res) => {
  const { name, email } = req.body;
  db.run('INSERT INTO affiliates (name, email) VALUES (?, ?)', [name, email], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: this.lastID, name, email, status: 'pending' });
  });
});

app.get('/api/affiliates', (req, res) => {
  db.all('SELECT * FROM affiliates', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/leads', (req, res) => {
  const { affiliateId, customerName, product } = req.body;
  db.run('INSERT INTO leads (affiliateId, customerName, product) VALUES (?, ?, ?)', 
    [affiliateId, customerName, product], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: this.lastID, affiliateId, customerName, product, status: 'new' });
  });
});

app.get('/api/leads', (req, res) => {
  db.all('SELECT * FROM leads', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/leads/:id/convert', (req, res) => {
  const { id } = req.params;
  db.get('SELECT * FROM leads WHERE id=?', [id], (err, lead) => {
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    db.run('UPDATE leads SET status=? WHERE id=?', ['converted', id]);
    db.run('UPDATE affiliates SET earnings = earnings + 800 WHERE id=?', [lead.affiliateId]);
    res.json({ message: 'Lead converted and earnings updated' });
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Affiliate backend running on ${PORT}`));