import React, { useState, useEffect } from 'react';

const API = process.env.REACT_APP_API || "http://localhost:4000/api";

export default function App() {
  const [affiliates, setAffiliates] = useState([]);
  const [leads, setLeads] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [product, setProduct] = useState('');
  const [affiliateId, setAffiliateId] = useState('');

  useEffect(() => {
    fetch(API + '/affiliates').then(r => r.json()).then(setAffiliates);
    fetch(API + '/leads').then(r => r.json()).then(setLeads);
  }, []);

  const signupAffiliate = async () => {
    const res = await fetch(API + '/affiliates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email })
    });
    const data = await res.json();
    alert('Affiliate signed up!');
    setAffiliates([...affiliates, data]);
  };

  const submitLead = async () => {
    const res = await fetch(API + '/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ affiliateId, customerName, product })
    });
    const data = await res.json();
    alert('Lead submitted!');
    setLeads([...leads, data]);
  };

  const convertLead = async (id) => {
    await fetch(API + '/leads/' + id + '/convert', { method: 'POST' });
    alert('Lead converted!');
    window.location.reload();
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Affiliate Program</h1>

      <h2>Affiliate Signup</h2>
      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
      <button onClick={signupAffiliate}>Sign Up</button>

      <h2>Submit Lead</h2>
      <input placeholder="Affiliate ID" value={affiliateId} onChange={e => setAffiliateId(e.target.value)} />
      <input placeholder="Customer Name" value={customerName} onChange={e => setCustomerName(e.target.value)} />
      <input placeholder="Product" value={product} onChange={e => setProduct(e.target.value)} />
      <button onClick={submitLead}>Submit Lead</button>

      <h2>Affiliates</h2>
      <ul>
        {affiliates.map(a => <li key={a.id}>{a.id} - {a.name} ({a.email}) Earnings: {a.earnings}</li>)}
      </ul>

      <h2>Leads</h2>
      <ul>
        {leads.map(l => (
          <li key={l.id}>
            {l.id} - {l.customerName} ({l.product}) [{l.status}]
            {l.status !== 'converted' && <button onClick={() => convertLead(l.id)}>Convert</button>}
          </li>
        ))}
      </ul>
    </div>
  );
}